//
//  GlobalMethod.swift
//  Construction App
//
//  Created by RANJIT on 25/07/20.
//  Copyright © 2020 RANJIT. All rights reserved.
//

import UIKit


var APPNAME = "Construction App"


extension String {
    func isValidEmail(testStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    func myMobileNumberValidate(_ number: String?) -> Bool {
        let numberRegEx = "[0-9]{10}"
        let numberTest = NSPredicate(format: "SELF MATCHES %@", numberRegEx)
        if numberTest.evaluate(with: number) == true {
            return true
        }
        else {
            return false
        }
    }
}
class GlobalMethod: NSObject {
    
    func isLoggedIn() -> Bool {
        let info = UserDefaults.standard.value(forKey: "")
        if info != nil {
            return true
        }
        return false
    }
    
    /*
     Image's Border Radius
     */
    
    func imgCircle( image: UIImageView, borderWidth: Int, masksToBounds: Bool, borderColor: UIColor, clipsToBounds: Bool) -> Void {
        image.layer.borderWidth = CGFloat(borderWidth)
        image.layer.masksToBounds = masksToBounds
        image.layer.borderColor = borderColor.cgColor
        image.layer.cornerRadius = image.frame.height/2
        image.clipsToBounds = true
    }
    
    func viewCircle( image: UIView, borderWidth: Int, masksToBounds: Bool, borderColor: UIColor, clipsToBounds: Bool) -> Void {
        image.layer.borderWidth = CGFloat(borderWidth)
        image.layer.masksToBounds = masksToBounds
        image.layer.borderColor = borderColor.cgColor
        image.layer.cornerRadius = image.frame.height/2
        image.clipsToBounds = true
    }
    
    func showAlert(title: String, message: String, vc: UIViewController) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        DispatchQueue.main.async {vc.present(alert, animated: true) }
    }
    
    func pushToVC(storyBoard: String, VCId: String, VC: UIViewController) {
        let story =  UIStoryboard.init(name: storyBoard, bundle: nil)
        let vc = story.instantiateViewController(withIdentifier: VCId)
        VC.navigationController?.pushViewController(vc, animated: true)
    }
    
    func presentToVC(storyBoard: String, VCId: String, VC: UIViewController) {
        let story =  UIStoryboard.init(name: storyBoard, bundle: nil)
        let vc = story.instantiateViewController(withIdentifier: VCId)
        VC.present(vc, animated: true, completion: nil)
    }
    
    func UTCToLocal(date:String) -> String {
        
        var dateStr:String = ""
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        let converteddate = dateFormatter.date(from: date)
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        if converteddate != nil {
            dateStr = dateFormatter.string(from: converteddate!)
        }
        return dateStr
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
}
