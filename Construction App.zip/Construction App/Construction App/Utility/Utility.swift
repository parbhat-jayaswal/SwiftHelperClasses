//
//  Utility.swift
//  Construction App
//
//  Created by RANJIT on 24/07/20.
//  Copyright © 2020 RANJIT. All rights reserved.
//

import Foundation
