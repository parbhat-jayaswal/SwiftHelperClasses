//
//  RoundRectView.swift
//  Construction App
//
//  Created by RANJIT on 24/07/20.
//  Copyright © 2020 RANJIT. All rights reserved.
//

import UIKit
class ShadowView: UIView {
  required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        // corner radius
        self.layer.cornerRadius = 50

        // border
    self.layer.borderWidth = 0.2
        self.layer.borderColor = UIColor.lightGray.cgColor

        // shadow
        self.layer.shadowColor = UIColor.lightGray.cgColor
        self.layer.shadowOffset = CGSize(width: 3, height: 3)
        self.layer.shadowOpacity = 0.7
        self.layer.shadowRadius = 4.0
    }
}

