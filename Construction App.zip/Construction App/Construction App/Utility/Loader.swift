//
//  Loader.swift
//  Construction App
//
//  Created by RANJIT on 25/07/20.
//  Copyright © 2020 RANJIT. All rights reserved.
//

import Foundation
import NVActivityIndicatorView


class Loader: UIViewController, NVActivityIndicatorViewable {
    
   static var shared = Loader()
    //ballGridPulse
    func show() {
        let activityData = ActivityData(size: nil, message: nil, messageFont: nil, messageSpacing: nil, type: .lineScalePulseOutRapid, color: #colorLiteral(red: 0.9215686275, green: 0.4117647059, blue: 0, alpha: 1), padding: nil, displayTimeThreshold: nil, minimumDisplayTime: nil, backgroundColor: nil, textColor: nil)
        
        NVActivityIndicatorPresenter.sharedInstance.startAnimating(activityData)
    }
    
    func hide() {
        stopAnimating()
    }
    
}
