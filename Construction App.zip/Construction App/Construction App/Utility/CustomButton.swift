//
//  CustomButton.swift
//  Construction App
//
//  Created by RANJIT on 25/07/20.
//  Copyright © 2020 RANJIT. All rights reserved.
//

import Foundation
import  UIKit

@IBDesignable
class LeftAlignedIconButton: UIButton {
    override func titleRect(forContentRect contentRect: CGRect) -> CGRect {
           let titleRect = super.titleRect(forContentRect: contentRect)
           let imageSize = currentImage?.size ?? .zero
           let availableWidth = contentRect.width - imageEdgeInsets.right - imageSize.width - titleRect.width
           return titleRect.offsetBy(dx: round(availableWidth / 2), dy: 0)
       }
}
