//
//  ApiConstant.swift
//  Construction App
//
//  Created by RANJIT on 25/07/20.
//  Copyright © 2020 RANJIT. All rights reserved.
//

import Foundation

let BASE_URL = "http://167.172.209.57/construction/api/v1/user/"


let SignUp = BASE_URL + "register"
let Login = BASE_URL + "login"
let verify_email_with_otp = BASE_URL + "verify_email_with_otp"


let changePassword = BASE_URL + "change_password"


let resend_otp = BASE_URL + "resend_otp"
let login_social = BASE_URL + "login_social"




