//
//  GlobalConstant.swift
//  Construction App
//
//  Created by RANJIT on 25/07/20.
//  Copyright © 2020 RANJIT. All rights reserved.
//

import Foundation
import UIKit
var appColor = UIColor(red: 67/255, green: 152/255, blue: 181/255, alpha: 1.0)
