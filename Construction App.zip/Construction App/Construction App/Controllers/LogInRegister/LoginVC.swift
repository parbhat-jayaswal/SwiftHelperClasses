//
//  LoginVC.swift
//  Construction App
//
//  Created by RANJIT on 24/07/20.
//  Copyright © 2020 RANJIT. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

import AuthenticationServices

@available(iOS 13.0, *)
class LoginVC: UIViewController {
    
    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var emailMobileTf: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    
    @IBOutlet weak var fbBtn: UIButton!
    @IBOutlet weak var googleBtn: UIButton!
    @IBOutlet weak var appleBtn: UIButton!
    
    @IBOutlet weak var appleSignInBtn: ASAuthorizationAppleIDButton!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 25
        mainView.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner]
        self.navigationController?.navigationBar.isHidden = true
        
//         fbBtn.leftImage(image: UIImage(named: "google")!, renderMode: .alwaysOriginal)
//        googleBtn.leftImage(image: UIImage(named: "google")!, renderMode: .alwaysOriginal)
//        appleBtn.leftImage(image: UIImage(named: "google")!, renderMode: .alwaysOriginal)
    }
  
    @IBAction func signUpBtn(_ sender: Any) {
        let vc = UIStoryboard.init(name: "LogInRegister", bundle: Bundle.main).instantiateViewController(withIdentifier: "RegisterVC") as? RegisterVC
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @IBAction func forgotPasswordAction(_ sender: Any) {
        let vc = UIStoryboard.init(name: "LogInRegister", bundle: Bundle.main).instantiateViewController(withIdentifier: "ForgetPasswordVC_Id") as? ForgetPasswordVC
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @IBAction func loginAction(_ sender: Any) {
        
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ContainerVC_Id") as? ContainerVC
        self.navigationController?.pushViewController(vc!, animated: true)

        
        /*
        guard let emailMobile = emailMobileTf.text, emailMobile != "" else {
            GlobalMethod.init().showAlert(title: APPNAME, message: "Please enter your email address or mobile", vc: self)
            return
        }
        
        guard let password = passwordTF.text, password != "" else {
            GlobalMethod.init().showAlert(title: APPNAME, message: "Please enter your password!", vc: self)
            return
        }
        // Check if any input is entered and not empty string
        guard let validInput = emailMobileTf.text, validInput != "" else {
             GlobalMethod.init().showAlert(title: APPNAME, message: "Enter either valid phone or email", vc: self)
          return
        }

        // Check if entered value is valid or not
        if validInput.myMobileNumberValidate(emailMobile) || validInput.isValidEmail(testStr: emailMobile) {
            if password.count < 6 {
                GlobalMethod.init().showAlert(title: APPNAME, message:"Please enter your password more then 5 character!", vc: self)
            }
            else {
                loginByApi(emailNumber: emailMobile, password: password)
            }
        } else {
            GlobalMethod.init().showAlert(title: APPNAME, message: "Enter either valid phone or email!", vc: self)
        }
        
        */
    }
    
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
}

@available(iOS 13.0, *)
extension LoginVC {
    private func loginByApi(emailNumber: String, password: String) {
        
        let parameters = [
            "login": emailNumber,
            "password":password,
            "device_type":"iphone",
            "device_id":UserDefaults.standard.value(forKey: "device_id") ?? "",
            "device_token":UserDefaults.standard.value(forKey: "FCM_Token") ?? "12345"
        ]
        print(parameters)
        
        Loader.shared.show()
        
        Alamofire.request(Login, method:.post, parameters:parameters, encoding: JSONEncoding.default).responseJSON { response in
            switch response.result {
            case .success:
                guard  let res = response.result.value else {
                    DispatchQueue.main.async(execute: {
                        Loader.shared.hide()
                    })
                    return
                }
                self.exterateLoginInfo(info: JSON(res))
                DispatchQueue.main.async(execute: {
                    Loader.shared.hide()
                })
            case .failure(let error):
                DispatchQueue.main.async(execute: {
                    GlobalMethod.init().showAlert(title: APPNAME, message:  error.localizedDescription + "!", vc: self)
                    Loader.shared.hide()
                })
            }
        }
    }
    
    func exterateLoginInfo(info: JSON) {
        print(info)
        print("LOGIN DATA IS HERE++++++++++++++++++++\(info)")
        if info["status"].stringValue == "200" {
            
            guard  let dataInfo = info["data"].dictionaryObject else {
                return
            }

            if let savedData = try? NSKeyedArchiver.archivedData(withRootObject: dataInfo, requiringSecureCoding: false) {
                 UserDefaults.standard.set(savedData, forKey: "loginInfo")
             }
            UserDefaults.standard.set(dataInfo["session_id"], forKey: "session_id")
            UserDefaults.standard.set(dataInfo["id"], forKey: "id")
            UserDefaults.standard.set(dataInfo["password"], forKey: "password")
            UserDefaults.standard.set(true, forKey: "isUserLoggedIn")
            
            let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ContainerVC_Id") as! ContainerVC
            self.navigationController?.pushViewController(vc, animated: true)

        }
        else if info["status"].stringValue == "400"{
             GlobalMethod.init().showAlert(title: APPNAME, message:  info["error_description"].stringValue + "!", vc: self)
        }
        else{
            GlobalMethod.init().showAlert(title: APPNAME, message:  info["message"].stringValue + "!", vc: self)
        }
    }
    
}



@available(iOS 13.0, *)
extension LoginVC {
    
    func checkStatusOfAppleSignIn() {
        if #available(iOS 13.0, *) {
            let appleIDProvider = ASAuthorizationAppleIDProvider()
            appleIDProvider.getCredentialState(forUserID: "\(UserDefaults.standard.value(forKey: "User_AppleID")!)") { (credentialState, error) in
                
                switch credentialState {
                case .authorized:
                    
                    break
                default:
                    break
                }
            }
        } else {
            // Fallback on earlier versions
        }
        
    }
    
    func setupAppleSignInButton() {
        appleSignInBtn.addTarget(self, action: #selector(self.actionHandleAppleSignin), for: .touchUpInside)
    }
    
    
    @objc func actionHandleAppleSignin() {
        DispatchQueue.main.async {
        }
        
        if #available(iOS 13.0, *) {
            let appleIDProvider = ASAuthorizationAppleIDProvider()
            let request = appleIDProvider.createRequest()
            request.requestedScopes = [.fullName, .email]
            
            let authorizationController = ASAuthorizationController(authorizationRequests: [request])
            authorizationController.delegate = self
            authorizationController.presentationContextProvider = self
            authorizationController.performRequests()

        } else {
            // Fallback on earlier versions
        }
        
    }
    
}

@available(iOS 13.0, *)
extension LoginVC : ASAuthorizationControllerDelegate
{
    @available(iOS 13.0, *)
    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        switch authorization.credential {
            
        case let credentials as ASAuthorizationAppleIDCredential:
            DispatchQueue.main.async {
                
                if "\(credentials.user)" != "" {
                    
                    UserDefaults.standard.set("\(credentials.user)", forKey: "User_AppleID")
                }
                if credentials.email != nil {
                    
                    UserDefaults.standard.set("\(credentials.email!)", forKey: "User_Email")
                }
                if credentials.fullName!.givenName != nil {
                    
                    UserDefaults.standard.set("\(credentials.fullName!.givenName!)", forKey: "User_FirstName")
                }
                if credentials.fullName!.familyName != nil {
                    
                    UserDefaults.standard.set("\(credentials.fullName!.familyName!)", forKey: "User_LastName")
                }
                UserDefaults.standard.synchronize()
                
                let fullName = credentials.fullName
//                self.loginFrom  = "apple"
                
                let id = credentials.user
                
                if let fName = fullName?.givenName, let lName = fullName?.familyName, let eMail = credentials.email {
                  //  self.loginWithSocial(firstName: fName, lastName: lName, Id: id, mobile: "", email: eMail, address: "")
                }
                
                
            }
            
        case let credentials as ASPasswordCredential:
            DispatchQueue.main.async {
                
                if "\(credentials.user)" != "" {
                    
                    UserDefaults.standard.set("\(credentials.user)", forKey: "User_AppleID")
                }
                if "\(credentials.password)" != "" {
                    
                    UserDefaults.standard.set("\(credentials.password)", forKey: "User_Password")
                }
                UserDefaults.standard.synchronize()
                
                if let fName = UserDefaults.standard.value(forKey: "User_FirstName") as? String, let lName = UserDefaults.standard.value(forKey: "User_LastName") as? String, let eMail = UserDefaults.standard.value(forKey: "User_Email") as? String, let id = UserDefaults.standard.value(forKey: "User_AppleID") as? String {
                   // self.loginWithSocial(firstName: fName, lastName: lName, Id: id, mobile: "", email: eMail, address: "")
                }
                
            }
            
        default :
            let alert: UIAlertController = UIAlertController(title: "Apple Sign In", message: "Something went wrong with your Apple Sign In!", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
            break
        }
    }
    
    
    @available(iOS 13.0, *)
    func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error)
    {
        let alert: UIAlertController = UIAlertController(title: "Error", message: "\(error.localizedDescription)", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
}

@available(iOS 13.0, *)
extension LoginVC : ASAuthorizationControllerPresentationContextProviding {
    func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        return view.window!
    }
}
