//
//  RegisterVC.swift
//  Construction App
//
//  Created by RANJIT on 24/07/20.
//  Copyright © 2020 RANJIT. All rights reserved.
//

import UIKit
import  Alamofire
import SwiftyJSON


class RegisterVC: UIViewController {
    
    
    @IBOutlet weak var mainView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 25
        mainView.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner]
        self.navigationController?.navigationBar.isHidden = true

    }
    
    
    @IBAction func goBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func registerAction(_ sender: Any) {
        
        
        let vc = UIStoryboard.init(name: "LogInRegister", bundle: Bundle.main).instantiateViewController(withIdentifier: "OtpVC_Id") as? OtpVC
        self.navigationController?.pushViewController(vc!, animated: true)
        
        
        /*
         
         
        guard let fname = fnameTf.text, fname != "" else {
            GlobalMethod.init().showAlert(title: APPNAME, message: "Please enter your first name!", vc: self)
            return
        }
        guard let lname = lnameTf.text, lname != "" else {
            GlobalMethod.init().showAlert(title: APPNAME, message: "Please enter your last name!", vc: self)
            return
        }
        guard let email = emailTf.text, email != "" else {
                GlobalMethod.init().showAlert(title: "Email Address", message: "Please enter your email address!", vc: self)
                return
            }
        guard let password = passwordTf.text, password != "" else {
            GlobalMethod.init().showAlert(title: APPNAME, message: "Please enter your password!", vc: self)
            return
        }
        guard let address = addressTf.text, address != "" else {
            GlobalMethod.init().showAlert(title: APPNAME, message: "Please enter your email address!", vc: self)
            return
        }
        guard let phone = mobileTf.text, phone != "" else {
            GlobalMethod.init().showAlert(title: APPNAME, message: "Please enter your phone Number!", vc: self)
            return
        }
        
        if email.isValidEmail(testStr: email) == false {
            GlobalMethod.init().showAlert(title: APPNAME, message: "Please enter your correct email address!", vc: self)
        }
        else if phone.myMobileNumberValidate(phone) == false{
         
            
            
            GlobalMethod.init().showAlert(title: APPNAME, message: "Please enter your correct phone number!", vc: self)
        }
        else  {
            if password.count < 6 {
                GlobalMethod.init().showAlert(title: APPNAME, message:"Please enter your password more then 5 character!", vc: self)
            }
            else {
                signupByApi(fname: fname, email: email, password: password,address:address, phone: phone)
                
            }
        }
        
        */
        
        
        
    }
    
}

extension RegisterVC {
    private func  signupByApi(fname: String, email: String, password: String,address:String, phone: String){
        
        let parameters = [
            "name":fname,
            "phone":"+91" + phone,
            "email":email,
            "password":password,
            "location":address,
            "device_type":"iphone",
            "device_id":"",
            "device_token":UserDefaults.standard.value(forKey: "FCM_Token") ?? "1232424"
        ]
        print(parameters)
        Loader.shared.show()
        
        Alamofire.request(SignUp, method:.post, parameters:parameters, encoding: JSONEncoding.default).responseJSON { response in
            switch response.result {
            case .success:
                guard  let res = response.result.value else {
                    DispatchQueue.main.async(execute: {
                        Loader.shared.hide()
                    })
                    return
                }
                self.exterateSignUpInfo(info: JSON(res))
                DispatchQueue.main.async(execute: {
                    Loader.shared.hide()
                })
            case .failure(let error):
                DispatchQueue.main.async(execute: {
                    GlobalMethod.init().showAlert(title: APPNAME, message: error.localizedDescription + "!", vc: self)
                    Loader.shared.hide()
                })
            }
        }
    }
    
    func exterateSignUpInfo(info: JSON) {
        print("SIGN UP DATA IS HERE++++++++++++++++++++\(info)")
        if info["status"].stringValue == "200" {
            let sessionID =   info["session_id"].stringValue
            print(sessionID)
            if info["message"].stringValue == "Check Registered Email for OTP"{
                let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "OTPVc") as? OtpVC
                vc?.sessionIdSignup = sessionID
                self.navigationController?.pushViewController(vc!, animated: true)
                GlobalMethod.init().showAlert(title: "Alert", message:  info["message"].stringValue + "!", vc: self)

            }
        }
        else if info["status"].stringValue == "400"{
            GlobalMethod.init().showAlert(title: APPNAME, message:  info["error_description"].stringValue + "!", vc: self)
        }
        else{
            GlobalMethod.init().showAlert(title: APPNAME, message:  info["message"].stringValue + "!", vc: self)
        }
    }
}
