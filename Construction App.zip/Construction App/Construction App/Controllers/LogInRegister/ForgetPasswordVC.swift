//
//  ForgetPasswordVC.swift
//  Construction App
//
//  Created by RANJIT on 24/07/20.
//  Copyright © 2020 RANJIT. All rights reserved.
//

import UIKit

class ForgetPasswordVC: UIViewController {
    
    @IBOutlet weak var mainView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()

        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 25
        mainView.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner]
        self.navigationController?.navigationBar.isHidden = true

    }

    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func nextBtn(_ sender: Any) {
        let vc = UIStoryboard.init(name: "LogInRegister", bundle: Bundle.main).instantiateViewController(withIdentifier: "OTPVc") as? OtpVC
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}
