//
//  OTPVc.swift
//  Construction App
//
//  Created by RANJIT on 24/07/20.
//  Copyright © 2020 RANJIT. All rights reserved.
//

import UIKit
import  Alamofire
import SwiftyJSON

class OtpVC: UIViewController {
    var sessionIdSignup : String?
    
    @IBOutlet weak var mainView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()

        mainView.clipsToBounds = true
        mainView.layer.cornerRadius = 25
        mainView.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner]
        self.navigationController?.navigationBar.isHidden = true
    }
    
    override func viewDidAppear(_ animated: Bool) {

    }
    
    @IBAction func nextBtnAction(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ContainerVC_Id") as? ContainerVC
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @IBAction func resentOTPBtnAction(_ sender: Any) {
        
    }
    
    @IBAction func goBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}

extension OtpVC : UITextFieldDelegate{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let maxLength = 1
        let currentString: NSString = textField.text! as NSString
        let newString: NSString =
            currentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= maxLength
    }
}



extension OtpVC {
    private func otpByApi(){
        
        let parameters = [
            "otp_num": "121323",
            "session_id": sessionIdSignup
        ]
        print(parameters)
        Loader.shared.show()
        
        Alamofire.request(verify_email_with_otp, method:.post, parameters:parameters as Parameters, encoding: JSONEncoding.default).responseJSON { response in
            switch response.result {
            case .success:
                guard  let res = response.result.value else {
                    DispatchQueue.main.async(execute: {
                        Loader.shared.hide()
                    })
                    return
                }
                self.exterateOtpInfo(info: JSON(res))
                DispatchQueue.main.async(execute: {
                    Loader.shared.hide()
                })
            case .failure(let error):
                DispatchQueue.main.async(execute: {
                    GlobalMethod.init().showAlert(title: APPNAME, message:  error.localizedDescription + "!", vc: self)
                    Loader.shared.hide()
                })
            }
        }
    }
    
    func exterateOtpInfo(info: JSON) {
        print(info)
        print("LOGIN DATA IS HERE++++++++++++++++++++\(info)")
        if info["status"].stringValue == "200" {
            GlobalMethod.init().showAlert(title: APPNAME, message:  info["message"].stringValue + "!", vc: self)
        }
        else if info["status"].stringValue == "400"{
            GlobalMethod.init().showAlert(title: APPNAME, message:  info["error_description"].stringValue + "!", vc: self)
        }
        else{
            GlobalMethod.init().showAlert(title: APPNAME, message:  info["message"].stringValue + "!", vc: self)
        }
    }
    
}
